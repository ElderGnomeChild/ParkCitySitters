from django.db import models
from django.contrib.auth.models import AbstractUser
from django.apps import apps
from sit.models import Language
# Create your models here.

class Babysitter(AbstractUser):
    # # babysitter_lname = models.CharField(max_length=30)
    # # babysitter_fname = models.CharField(max_length=30)
    babysitter_phone = models.CharField(max_length=16, default="not set")
    # # babysitter_email = models.EmailField(max_length=70)
    babysitter_years_of_experience = models.PositiveIntegerField(default=0)
    babysitter_address_street1 = models.CharField(max_length=50, default="no address on file")
    babysitter_address_street2 = models.CharField(max_length=20, blank=True, null=True)
    babysitter_address_city = models.CharField(max_length=25, null=True)
    babysitter_address_state = models.CharField(max_length=2, default="UT")
    babysitter_address_zip = models.PositiveIntegerField(default="00000")

    babysitter_works_with_disabilities = models.BooleanField(default=False)
    babysitter_age01_or_younger = models.BooleanField(default=False)
    babysitter_age02 = models.BooleanField(default=True)
    babysitter_age03 = models.BooleanField(default=True)
    babysitter_age04 = models.BooleanField(default=True)
    babysitter_age05 = models.BooleanField(default=True)
    babysitter_age06 = models.BooleanField(default=True)
    babysitter_age07 = models.BooleanField(default=True)
    babysitter_age08 = models.BooleanField(default=True)
    babysitter_age09 = models.BooleanField(default=True)
    babysitter_age10 = models.BooleanField(default=True)
    babysitter_age11 = models.BooleanField(default=True)
    babysitter_age12_plus = models.BooleanField(default=True)

    # babysitter_languages = models.ManyToManyField(Language)

# class Boss(AbstractUser):
#     pass

    